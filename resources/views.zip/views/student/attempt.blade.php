<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>الاختبار</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container py-4" style="max-width: 820px;">

  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <div class="small text-white-50">اليوم {{ $competition->day_number }} — سؤال {{ $current }} / {{ $total }}</div>
      <h4 class="mb-0">الوقت المتبقي: <span id="timer">{{ $remaining }}</span> ث</h4>
    </div>
    <form method="POST" action="{{ route('logout') }}">
      @csrf
      <button class="btn btn-outline-light btn-sm">خروج</button>
    </form>
  </div>

  <div class="card text-dark shadow-sm">
    <div class="card-body">
      <h5 class="mb-4">{{ $question->text }}</h5>

      <form id="answerForm" method="POST" action="{{ route('attempt.answer', $attempt) }}">
        @csrf

        <input type="hidden" name="selected_choice" id="selected_choice">
        <input type="hidden" name="confirm" value="yes">

        <div class="d-grid gap-2">
          <button type="button" class="btn btn-outline-dark text-start" onclick="pick('A')">A) {{ $question->choice_a }}</button>
          <button type="button" class="btn btn-outline-dark text-start" onclick="pick('B')">B) {{ $question->choice_b }}</button>
          <button type="button" class="btn btn-outline-dark text-start" onclick="pick('C')">C) {{ $question->choice_c }}</button>
          <button type="button" class="btn btn-outline-dark text-start" onclick="pick('D')">D) {{ $question->choice_d }}</button>
        </div>
      </form>

      <div class="text-muted small mt-3">
        لا يمكنك الرجوع للسؤال السابق. عند انتهاء الوقت سيتم الانتقال تلقائيًا.
      </div>
    </div>
  </div>
</div>

<script>
  let remaining = Number(document.getElementById('timer').innerText);
  const timerEl = document.getElementById('timer');

  const tick = setInterval(() => {
    remaining--;
    timerEl.innerText = remaining;

    if (remaining <= 0) {
      clearInterval(tick);
      // إعادة تحميل الصفحة ليقوم السيرفر بعمل auto-advance
      location.reload();
    }
  }, 1000);

  function pick(choice) {
    if (!confirm('هل تريد تأكيد الإجابة؟')) return;
    document.getElementById('selected_choice').value = choice;
    document.getElementById('answerForm').submit();
  }
</script>
</body>
</html>
