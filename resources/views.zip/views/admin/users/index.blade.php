<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>إدارة المستخدمين</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">إدارة المستخدمين</h3>

      <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button class="btn btn-outline-dark btn-sm">تسجيل خروج</button>
      </form>
    </div>

    @if(session('ok'))
      <div class="alert alert-success">{{ session('ok') }}</div>
    @endif

    <form class="row g-2 mb-3" method="GET" action="{{ route('admin.users') }}">
      <div class="col-12 col-md-9">
        <input class="form-control" name="q" value="{{ $q }}" placeholder="بحث: اسم / إيميل / هاتف / رقم قيد">
      </div>
      <div class="col-12 col-md-3 d-grid">
        <button class="btn btn-dark">بحث</button>
      </div>
    </form>

    <ul class="nav nav-tabs" id="tabs" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#pending" type="button">قيد المراجعة</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#approved" type="button">مقبولون</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#rejected" type="button">مرفوضون</button>
      </li>
    </ul>

    <div class="tab-content bg-white border border-top-0 p-3">
      {{-- Pending --}}
      <div class="tab-pane fade show active" id="pending">
        @include('admin.users.partials.table', ['rows' => $pending, 'mode' => 'pending'])
        <div class="mt-3">{{ $pending->withQueryString()->links() }}</div>
      </div>

      {{-- Approved --}}
      <div class="tab-pane fade" id="approved">
        @include('admin.users.partials.table', ['rows' => $approved, 'mode' => 'approved'])
        <div class="mt-3">{{ $approved->withQueryString()->links('pagination::bootstrap-5') }}</div>
      </div>

      {{-- Rejected --}}
      <div class="tab-pane fade" id="rejected">
        @include('admin.users.partials.table', ['rows' => $rejected, 'mode' => 'rejected'])
        <div class="mt-3">{{ $rejected->withQueryString()->links('pagination::bootstrap-5') }}</div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>