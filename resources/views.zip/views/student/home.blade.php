<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>الأيام</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">

<div class="container py-4">

  {{-- Header --}}
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h4 class="mb-1">مرحبًا، {{ auth()->user()->name }}</h4>
      <div class="text-white-50 small">اختر يوم المسابقة</div>
    </div>

    <form method="POST" action="{{ route('logout') }}">
      @csrf
      <button class="btn btn-outline-light btn-sm">تسجيل خروج</button>
    </form>
  </div>

  {{-- رسالة خطأ --}}
  @if(session('err'))
    <div class="alert alert-danger">
      {{ session('err') }}
    </div>
  @endif

  {{-- الأيام --}}
  <div class="row g-3">

    @forelse($days as $d)
      <div class="col-12 col-md-6 col-lg-4">

        <div class="card h-100 shadow-sm border-0">
          <div class="card-body text-dark">

            {{-- عنوان اليوم --}}
            <div class="d-flex justify-content-between align-items-center">
              <h5 class="mb-0">اليوم {{ $d['day_number'] }}</h5>

              @if($d['status'] === 'open')
                <span class="badge bg-success">مفتوح الآن</span>
              @elseif($d['status'] === 'closed')
                <span class="badge bg-secondary">مغلق</span>
              @else
                <span class="badge bg-warning text-dark">قادم</span>
              @endif
            </div>

            {{-- عنوان اختياري --}}
            @if($d['title'])
              <div class="mt-2 text-muted">
                {{ $d['title'] }}
              </div>
            @endif

            {{-- أوقات --}}
            <div class="mt-3 small text-muted">
              يبدأ: {{ \Carbon\Carbon::parse($d['starts_at'])->format('Y-m-d h:i A') }}<br>
              ينتهي: {{ \Carbon\Carbon::parse($d['ends_at'])->format('Y-m-d h:i A') }}
            </div>

            {{-- زر الإجراء --}}
            <div class="mt-3">

              {{-- إذا مفتوح --}}
              @if($d['status'] === 'open')
                <form method="POST" action="{{ route('attempt.start', $d['id']) }}">
                  @csrf
                  <button class="btn btn-dark w-100">
                    ابدأ الاختبار
                  </button>
                </form>

              {{-- إذا مغلق --}}
              @elseif($d['status'] === 'closed')
                <a class="btn btn-outline-dark w-100"
                   href="#"
                   onclick="alert('قريبًا: سيتم عرض الفائزين هنا')">
                  عرض الفائزين
                </a>

              {{-- إذا قادم --}}
              @else
                <button class="btn btn-outline-secondary w-100" disabled>
                  غير متاح الآن
                </button>
              @endif

            </div>

          </div>
        </div>

      </div>
    @empty

      <div class="col-12">
        <div class="alert alert-warning text-center">
          لا توجد مسابقات منشورة حاليًا.
        </div>
      </div>

    @endforelse

  </div>

</div>

</body>
</html>
