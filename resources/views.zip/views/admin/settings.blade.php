<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>إعدادات النظام</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-4" style="max-width: 820px;">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">إعدادات النظام</h3>

      <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button class="btn btn-outline-dark btn-sm">تسجيل خروج</button>
      </form>
    </div>

    @if(session('ok'))
      <div class="alert alert-success">{{ session('ok') }}</div>
    @endif

    <form method="POST" action="{{ route('admin.settings.update') }}" class="card p-4 shadow-sm">
      @csrf

      <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" role="switch"
               id="auto_approve_enabled" name="auto_approve_enabled"
               {{ $autoApprove ? 'checked' : '' }}>
        <label class="form-check-label" for="auto_approve_enabled">
          تفعيل القبول التلقائي (أي طالب يسجل يتم قبوله مباشرة)
        </label>
      </div>

      <button class="btn btn-dark mt-4">حفظ</button>

      <div class="text-muted small mt-3">
        إذا أغلقت القبول التلقائي، سيتم تحويل المسجلين الجدد إلى Pending (قيد المراجعة).
      </div>
    </form>
  </div>
</body>
</html>