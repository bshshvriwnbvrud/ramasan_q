<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>إدارة أيام رمضان</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">

<h3>أيام رمضان</h3>

@if(session('ok'))
<div class="alert alert-success">{{ session('ok') }}</div>
@endif

<a href="{{ route('admin.competitions.create') }}" class="btn btn-dark mb-3">إنشاء يوم جديد</a>

<table class="table table-bordered">
<thead>
<tr>
<th>اليوم</th>
<th>العنوان</th>
<th>البداية</th>
<th>النهاية</th>
<th>الحالة</th>
<th>إجراء</th>
</tr>
</thead>
<tbody>
@foreach($competitions as $c)
<tr>
<td>{{ $c->day_number }}</td>
<td>{{ $c->title }}</td>
<td>{{ $c->starts_at }}</td>
<td>{{ $c->ends_at }}</td>
<td>
<span class="badge bg-{{ $c->is_published ? 'success' : 'secondary' }}">
{{ $c->is_published ? 'منشور' : 'غير منشور' }}
</span>
</td>
<td>
<form method="POST" action="{{ route('admin.competitions.toggle',$c) }}">
@csrf
<button class="btn btn-sm btn-warning">تغيير الحالة</button>
</form>
</td>
</tr>
@endforeach
</tbody>
</table>

</div>
</body>
</html>