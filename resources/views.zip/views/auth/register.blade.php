<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>تسجيل جديد</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5" style="max-width: 520px;">
    <h3 class="mb-4 text-center">تسجيل جديد</h3>

    @if ($errors->any())
      <div class="alert alert-danger">
        <ul class="mb-0">
          @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
          @endforeach
        </ul>
      </div>
    @endif

    <form method="POST" action="{{ route('register.post') }}" class="card p-4 shadow-sm">
      @csrf

      <div class="mb-3">
        <label class="form-label">الاسم</label>
        <input name="name" class="form-control" value="{{ old('name') }}" required>
      </div>

      <div class="mb-3">
        <label class="form-label">الإيميل</label>
        <input type="email" name="email" class="form-control" value="{{ old('email') }}" required>
      </div>

      <div class="mb-3">
        <label class="form-label">رقم الهاتف</label>
        <input name="phone" class="form-control" value="{{ old('phone') }}" required>
      </div>

      <div class="mb-3">
        <label class="form-label">التخصص (اختياري)</label>
        <input name="major" class="form-control" value="{{ old('major') }}">
      </div>

      <div class="mb-3">
        <label class="form-label">رقم القيد (اختياري)</label>
        <input name="student_no" class="form-control" value="{{ old('student_no') }}">
        <div class="form-text">إذا كان رقم القيد موجود عند الإدارة قد يتم قبولك تلقائيًا.</div>
      </div>

      <div class="mb-3">
        <label class="form-label">كلمة المرور</label>
        <input type="password" name="password" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">تأكيد كلمة المرور</label>
        <input type="password" name="password_confirmation" class="form-control" required>
      </div>

      <button class="btn btn-dark w-100">تسجيل</button>

      <div class="text-center mt-3">
        لديك حساب؟ <a href="{{ route('login') }}">تسجيل دخول</a>
      </div>
    </form>
  </div>
</body>
</html>
