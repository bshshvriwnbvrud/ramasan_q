<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>إنشاء يوم</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4" style="max-width:600px">

<h3>إنشاء يوم جديد</h3>

@if ($errors->any())
<div class="alert alert-danger">
<ul>
@foreach ($errors->all() as $error)
<li>{{ $error }}</li>
@endforeach
</ul>
</div>
@endif

<form method="POST" action="{{ route('admin.competitions.store') }}" class="card p-4 shadow">
@csrf

<div class="mb-3">
<label>رقم اليوم (1-30)</label>
<input type="number" name="day_number" class="form-control" required>
</div>

<div class="mb-3">
<label>عنوان اليوم</label>
<input type="text" name="title" class="form-control">
</div>

<div class="mb-3">
<label>وقت البداية</label>
<input type="datetime-local" name="starts_at" class="form-control" required>
</div>

<div class="mb-3">
<label>وقت النهاية</label>
<input type="datetime-local" name="ends_at" class="form-control" required>
</div>

<button class="btn btn-dark w-100">حفظ</button>

</form>

</div>
</body>
</html>