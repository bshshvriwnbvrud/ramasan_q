<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>مسابقة رمضان</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
  <div class="container py-5 text-center">
    <h1 class="fw-bold mb-3">🌙 مسابقة رمضان</h1>
    <p class="text-white-50 mb-4">اختبارات يومية من 9 إلى 11 مساءً</p>

    <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
      <a class="btn btn-warning btn-lg" href="{{ route('register') }}">تسجيل جديد</a>
      <a class="btn btn-outline-light btn-lg" href="{{ route('login') }}">تسجيل دخول</a>
    </div>
  </div>
</body>
</html>
