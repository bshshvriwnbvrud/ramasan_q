<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>النتيجة</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
<div class="container py-5" style="max-width: 720px;">
  <div class="card p-4 shadow text-dark">
    <h3 class="mb-2">انتهى الاختبار ✅</h3>
    <div class="mb-3 text-muted">اليوم {{ $attempt->competition->day_number }}</div>

    <div class="row g-2">
      <div class="col-12 col-md-4">
        <div class="border rounded p-3">
          <div class="text-muted small">الصحيح</div>
          <div class="fs-3 fw-bold">{{ $attempt->correct_count }}</div>
        </div>
      </div>
      <div class="col-12 col-md-4">
        <div class="border rounded p-3">
          <div class="text-muted small">الخطأ</div>
          <div class="fs-3 fw-bold">{{ $attempt->wrong_count }}</div>
        </div>
      </div>
      <div class="col-12 col-md-4">
        <div class="border rounded p-3">
          <div class="text-muted small">بدون إجابة</div>
          <div class="fs-3 fw-bold">{{ $attempt->blank_count }}</div>
        </div>
      </div>
    </div>

    <div class="mt-4">
      <a class="btn btn-dark w-100" href="{{ route('home') }}">العودة للرئيسية</a>
    </div>
  </div>
</div>
</body>
</html>
